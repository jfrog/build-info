module gitlab.com/jfrog-qa3/go-test-module

go 1.21.0
