module gitlab.com/jfrog-qa3/go-test-module/v2

go 1.21.0
