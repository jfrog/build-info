module github.com/p4r53c/go-lic-repro/pkg/module1

go 1.25
