package module2

func Hello() string { return "m2" }

