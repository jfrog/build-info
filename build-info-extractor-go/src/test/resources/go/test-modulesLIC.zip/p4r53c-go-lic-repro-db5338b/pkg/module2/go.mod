module github.com/p4r53c/go-lic-repro/pkg/module2

go 1.25
