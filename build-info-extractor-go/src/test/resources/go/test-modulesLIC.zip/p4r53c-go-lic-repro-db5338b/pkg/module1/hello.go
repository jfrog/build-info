package module1

func Hello() string { return "m1" }
