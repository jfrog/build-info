module github.com/thepudds/nested-module-example/contrib/nested1/v2

go 1.21
