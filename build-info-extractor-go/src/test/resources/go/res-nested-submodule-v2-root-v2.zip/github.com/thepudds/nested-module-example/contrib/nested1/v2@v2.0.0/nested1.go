package nested1

func Nested1() {}
