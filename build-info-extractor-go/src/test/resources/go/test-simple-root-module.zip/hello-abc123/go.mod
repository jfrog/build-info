module github.com/owner/hello

go 1.21
