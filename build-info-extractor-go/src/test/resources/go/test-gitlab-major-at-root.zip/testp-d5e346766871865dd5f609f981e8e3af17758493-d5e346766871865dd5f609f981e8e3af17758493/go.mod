module gitlab.com/techme-group/testp/v2

go 1.26.2
