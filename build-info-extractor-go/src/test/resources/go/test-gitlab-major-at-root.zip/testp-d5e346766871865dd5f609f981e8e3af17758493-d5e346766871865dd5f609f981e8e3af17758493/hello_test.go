package v2

import "testing"

func TestHello(t *testing.T) {
	got := Hello()
	want := "hello"

	if got != want {
		t.Fatalf("got=%s want=%s", got, want)
	}
}
