package v2

func Hello() string {
	return "hello v2"
}
