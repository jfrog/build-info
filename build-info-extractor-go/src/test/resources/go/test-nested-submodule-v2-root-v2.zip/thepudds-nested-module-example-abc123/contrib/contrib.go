package contrib

func Contrib() {}
