module github.com/thepudds/nested-module-example/contrib/nested2/v2

go 1.21
