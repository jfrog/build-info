package nested2

func Nested2() {}
