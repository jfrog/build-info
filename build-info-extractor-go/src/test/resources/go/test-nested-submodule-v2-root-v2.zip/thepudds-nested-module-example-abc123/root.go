package nestedmoduleexample

func Root() {}
