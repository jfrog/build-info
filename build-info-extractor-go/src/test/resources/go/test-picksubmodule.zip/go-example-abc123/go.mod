module github.com/owner/go-example

go 1.19
