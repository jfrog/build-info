module github.com/owner/go-example/helloserver

go 1.19
