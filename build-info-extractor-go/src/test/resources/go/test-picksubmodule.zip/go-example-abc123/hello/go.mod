module github.com/owner/go-example/hello

go 1.19
