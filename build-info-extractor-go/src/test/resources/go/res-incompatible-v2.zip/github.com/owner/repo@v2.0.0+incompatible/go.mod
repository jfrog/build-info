module github.com/owner/repo

go 1.11
