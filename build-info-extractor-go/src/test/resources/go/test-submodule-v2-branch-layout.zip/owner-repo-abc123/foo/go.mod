module github.com/owner/repo/foo/v2

go 1.21
